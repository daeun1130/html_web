$(document).ready(function(){

});//오픈